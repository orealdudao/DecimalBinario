package TAD;

import java.util.Stack;

public class Teste {
	
	private static Stack<Integer> pilha = new Stack<>();
	private static String entrada = "";
	private static int mod;
	

	public static  String conversor(int numero){		

	for (int i = 0; i <= 15; i++) {
			
		
	try {
		while (numero > 0){
		
			mod = numero % 2;
			pilha.push(mod);
			numero /= 2; 
			//n�mero = n�mero /2
	}

	while (!pilha.isEmpty()){
		
		entrada += pilha.pop();
		}
	//return entrada;
	 

} catch (NullPointerException erro) {
	// TODO: handle exception
	System.out.println(" Numero invalido! Insira novamente" + erro);
}
	
	}
	return entrada;
	}
	
	
	public static void setBinario(String binario) {
		Teste.entrada = binario;
	}
	
	
	
	public static String getBinario(String string) {
		return entrada;
	}
	
	public void imprimir(int numero, String conversor) {
		// TODO Auto-generated method stub
		System.out.printf(numero + " em bin�rio �: " + getBinario(conversor));
	}	
}


