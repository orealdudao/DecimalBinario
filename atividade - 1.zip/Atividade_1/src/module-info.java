/**
 * 
 */
/**
 * @author edu_n
 *
 */
module Atividade_1 {
	requires java.desktop;
}