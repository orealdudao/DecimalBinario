package APP;

import java.util.Scanner;

import TAD.Teste;

public class AppConversor {

	public static void main(String[] args) {
			
		
		//imprimir Nomes e RA
		
		/*
		 * Eduardo Neto - RA: 21292799
		 * Felipe Rosendo - RA: 21145513
		 * Lucas Magalh�es - RA: 21288328
		 * Matheus Soares - RA: 21336427
		 */
		
		String grupo[] = {"Eduardo Neto", "Felipe Rosendo", "Lucas Magalh�es", "Matheus Soares"};
		int ra[] = {21292799, 21145513, 21288328, 21336427};
		int cont;
		
		System.out.println("");
		System.out.println("        Integrantes do Grupo");
		System.out.println("--------------------------------------");
		for(cont = 0; cont < 4; cont++) {
			
			System.out.printf("| %s --> RA: %d \n", grupo[cont], ra[cont]);
		}
		System.out.println("--------------------------------------");
		System.out.println("");
		
		
		//Scanner
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Insira um n�mero:  ");
		int numero = scan.nextInt();
		
		
		//Com metodo imprimir**
		 Teste app = new Teste();
		 app.imprimir(numero, Teste.conversor(numero));
		 

		//Sem metodo imprimir**
		//System.out.println(numero + " em bin�rio �: " + Teste.conversor(numero));
		
		
		// erro com numeros negativos
		
	}
}