package TAD;

import java.util.Stack;

public class Teste {
	
	private static Stack<Integer> pilha = new Stack<>();
	private static String entrada = "";
	private static int mod;

	
	public static void setBinario(String binario) {
		entrada = binario;
	}
	
	
	
	public static String getBinario() {
		return entrada;
	}



	public static  String conversor(int numero){		
		
	if (numero > 0) {

		while (numero > 0){
		
			mod = numero % 2;
			pilha.push(mod);
			numero /= 2; 
			//número = número /2
	}

	while (!pilha.isEmpty()){
		
		entrada += pilha.pop();
		}
	

		} else {
			 System.out.println(" Numero invalido! Insira novamente \n");
	}
	
	return entrada;
	 }

	public void imprimir(int numero, String conversor) {
		// TODO Auto-generated method stub
		System.out.printf(numero + " em bin�rio �: " + getBinario());
		
	}	
}

//
//	public static  void conversor(int numero){		
//
//	
//		while (numero > 0){
//		
//			mod = numero % 2;
//			pilha.push(mod);
//			numero /= 2; 
//			//n�mero = n�mero /2
//	}
//
//	while (!pilha.isEmpty()){
//		
//		entrada += pilha.pop();
//		}
//	//return entrada;
//	 
//
//	return entrada;
//	//System.out.println(" Numero invalido! Insira novamente" + erro);	
//	}
//	
//	
//	public static void setBinario(int binario) {
//		Teste.entrada = binario;
//	}
//	
//	
//	
//	public static double getBinario(int d) {
//		
//		
//		return entrada;
//	}
//	
//	
//	//public void imprimir(double numero, double d) {
//		// TODO Auto-generated method stub
//		
//	//}
//
//
//	public void imprimir(double numero, double conversor) {
//		// TODO Auto-generated method stub
//		System.out.printf(numero + " em bin�rio �: \n" + getBinario(conversor));
//	}	
//}


