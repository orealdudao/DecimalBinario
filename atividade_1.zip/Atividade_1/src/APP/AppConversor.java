package APP;

import java.util.Scanner;

import TAD.Teste;

public class AppConversor {

	public static void main(String[] args) {
			
		
		//imprimir Nomes e RA
		
		/*
		 * Eduardo Neto - RA: 21292799
		 * Felipe Rosendo - RA: 21145513
		 * Lucas Magalh�es - RA: 21288328
		 * Matheus Soares - RA: 21336427
		 */
		
		String grupo[] = {"Eduardo Neto", "Felipe Rosendo", "Lucas Magalh�es", "Matheus Soares"};
		int ra[] = {21292799, 21145513, 21288328, 21336427};
		int cont;
		
		System.out.println("");
		System.out.println("        Integrantes do Grupo");
		System.out.println("--------------------------------------");
		for(cont = 0; cont < 4; cont++) {
			
			System.out.printf("| %s --> RA: %d \n", grupo[cont], ra[cont]);
		}
		System.out.println("--------------------------------------");
		System.out.println("");
		
		//Scanner
				@SuppressWarnings("resource")
				Scanner scan = new Scanner(System.in);
				
		                for (int i = 0; i < 40; i++) {
		                    System.out.print("\nInsira um n�mero:  ");
		                    int numero = scan.nextInt();
				
		                    if (numero < 0) {
		                        System.out.println("\nErro, n�o � permitido n�meros negativos!");
		                    } else {
		                        Teste app = new Teste();
		                        app.imprimir(numero, Teste.conversor((int)numero));
		                    }                     
		                }		
	}
}